from datetime import date
from datetime import datetime, timedelta
from flask import jsonify
from flask import request
from flask_restful import Resource
from mysql.connector import Error
from flask_mail import Message, Mail

from config import openmysqlconnection, closemysqlconnection
from mail import mail,app1
from flask_restful import Api
from flask import Flask
app = Flask(__name__)

today = date.today()
mail=Mail(app1)



class PolicyRegister(Resource):
    def post(self):

        try:

            policy_json = request.json
            policy_name = policy_json['policy_name']
            start_date = policy_json['start_date']
            duration_in_years = policy_json['duration_in_years']
            company_name = policy_json['company_name']
            initial_deposit = policy_json['initial_deposit']
            policy_type = policy_json['policy_type']
            user_type = policy_json['user_type']
            terms_per_year = policy_json['terms_per_year']
            term_amount = policy_json['term_amount']
            interest = policy_json['interest']

            #-----Policy_Id generation----#

            if policy_type == 'Vehicle Insurance':
                policy_type_id = 'VI'
            elif policy_type == 'Travel Insurance':
                policy_type_id = 'TI'
            elif policy_type == 'Health Insurance':
                policy_type_id = 'HI'
            elif policy_type == 'Life Insurance':
                policy_type_id = 'LI'
            elif policy_type == 'Child Plans':
                policy_type_id = 'CP'
            elif policy_type == 'Retirement Plans':
                policy_type_id = 'RT'

            connection = openmysqlconnection()
            cursor = connection.cursor()
            cursor.execute("SELECT policy_id FROM policy")
            policylist = cursor.fetchall()
            if len(policylist) == 0:
                num = '001'
            else:
                for itr in policylist:

                    policyid = itr[0]
                    if policy_type_id == (policyid.split('-')[0]):
                        latestpid = (policyid.split('-')[2])
                    else:
                        latestpid = "0000"
                num = "{:03d}".format(int(latestpid) + 1)

            #----calculating maturity amount-------#
            year_of_start_date = today.strftime("%Y")
            policy_id = policy_type_id + '-' + year_of_start_date + '-' + str(num)
            x = int(duration_in_years) * int(terms_per_year) * int(term_amount)
            y = int(interest) / 100
            maturity_amount = int(initial_deposit) + x + (x * y)

            #-------calculating end date---------#
            startdate = datetime.strptime(start_date, '%d/%m/%Y')
            duration = duration_in_years
            total_days = int(duration) * 365
            end_date = (startdate + timedelta(days=total_days)).strftime("%d/%m/%Y")

            #Inserting data into database-----#
            sqlQuery = "INSERT INTO policy (policy_name,start_date,duration_in_years,company_name,initial_deposit,policy_type,user_type,terms_per_year,term_amount,interest,policy_id,maturity_amount,end_date) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            bindData = (
            policy_name, start_date, duration_in_years, company_name, initial_deposit, policy_type, user_type, terms_per_year, term_amount, interest, policy_id, maturity_amount,end_date)
            cursor.execute(sqlQuery, bindData)
            connection.commit()
            #-----EMAIL GENARATION------#
            email='nayakinaveen@gmail.com'
            msg = Message('Policy Registration Details', sender='nayakinaveen@gmail.com', recipients=[email])
            msg.body = """Dear Admin 
                        The policy is successfully registered. 
                        The policy %s is available to the users from %s to %s 
                        This is the %s th policy in the %s. """ % (policy_id,start_date,end_date,num,policy_type)
            mail.send(msg)
            respone = jsonify('Policy details added successfully!')
            respone.status_code = 200
            return respone

        except Error as e:
            print("Error while connecting to MySQL", e)
        finally:
            closemysqlconnection(cursor,connection)


#-----fetching PolicyList from database------#

class PolicyList(Resource):
    def get(self):
        try:
            connection = openmysqlconnection()
            cursor= connection.cursor()
            cursor.execute("SELECT * from policy;")
            policyList = cursor.fetchall()
            respone = jsonify(policyList)
            respone.status_code = 200
            return respone
        except Exception as e:
            print(e)
        finally:
            closemysqlconnection(cursor,connection)


