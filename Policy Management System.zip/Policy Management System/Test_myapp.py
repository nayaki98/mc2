import unittest
from PolicySearch.policysearch import userLogin
from GetPolicyDocument.getdocument import getDocument
from UserResource.user import UserRegister
class TestStringMethods(unittest.TestCase):


    # Returns True if the string contains 4 a.
    def test_methods_login(self):
        userid="A-0002"
        password="19August_446"
        self.assertEqual(userLogin(userid,password),'User logged into the system')

    def test_methods_getdocumet(self):
        policyid="HI-2020-001"
        self.assertNotEqual(getDocument(policyid),'')






if __name__ == '__main__':
    unittest.main()