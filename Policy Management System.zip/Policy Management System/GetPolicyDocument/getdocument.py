import pdfkit
from flask import Flask
from flask import render_template, make_response
from config import closemysqlconnection, openmysqlconnection

app = Flask(__name__)

@app.route('/getDocument/<string:policy_id>')
def getDocument(policy_id):
        try:
            connection = openmysqlconnection()
            print("connected to the db")
            cursor = connection.cursor(prepared=True)
            inputdata = (policy_id,)
            sqlquery = "SELECT policy_name,initial_deposit,duration_in_years, terms_per_year, term_amount, interest, maturity_amount FROM policy WHERE policy_id = %s"
            cursor.execute(sqlquery, inputdata)
            policylist = cursor.fetchall()
            if len(policylist)==0:
                return "No polices for search criteria"
            policylist=policylist[0]
            policy_name = policylist[0]
            initial_deposit = policylist[1]
            duration_in_years = policylist[2]
            terms_per_year = policylist[3]
            term_amount = policylist[4]
            interest = policylist[5]
            maturity_amount = policylist[6]
            # print(policy_name,initial_deposit,duration_in_years, terms_per_year, term_amount, interest,maturity_amount)
            with app.app_context():
                        rendered = render_template('policypdf.html', \
                                                   policy_id=policy_id,
                                                   policy_name=policy_name,
                                                   initial_deposit=initial_deposit,
                                                   duration_in_years=duration_in_years,
                                                   terms_per_year=terms_per_year,
                                                   term_amount=term_amount,
                                                   interest=interest,
                                                   maturity_amount=maturity_amount
                                                   )
                        config = pdfkit.configuration(
                            wkhtmltopdf="C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe")
                        pdf = pdfkit.from_string(rendered, False, configuration=config)
                        response = make_response(pdf)
                        response.headers['Content-Type'] = 'application/pdf'
                        response.headers['Content-Disposition'] = 'inline; filename=policydocument'
                        return response
        except Exception as e:
            print(e)
        finally:
            closemysqlconnection(cursor, connection)


if __name__ == '__main__':
    app.run(port=5004, debug=True)