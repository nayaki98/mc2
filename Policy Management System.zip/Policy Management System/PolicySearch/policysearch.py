import mysql
from flask import jsonify, app, g
from flask import Flask
from flask_httpauth import HTTPBasicAuth

from config import openmysqlconnection, closemysqlconnection

app = Flask(__name__)
auth = HTTPBasicAuth()


@app.route('/api/token')
@auth.login_required
def get_auth_token():
    token = g.user.generate_auth_token()
    return jsonify({'token': token.decode('ascii')})


@app.route('/userlogin/<string:user_id>/<string:password>')
def userLogin(user_id,password):

    try:
        connection = openmysqlconnection()
        cursor = connection.cursor()
        inputdata = (user_id,password,)
        sqlquery="SELECT user_id,password FROM user WHERE user_id = %s and password = %s"
        cursor.execute(sqlquery, inputdata)
        userloginlist = cursor.fetchone()

        if userloginlist:

            userid_temp = userloginlist[0]
            password_temp = userloginlist[1]
            if userid_temp==user_id and password_temp==password:
                return "User logged into the system"
        else:
            return "Invalid usename and password"
    except Exception as e:
            print(e)

    finally:
        closemysqlconnection(cursor, connection)

@app.route('/policySearch/<int:searchtype>/<string:searchstring>')
def policySearch(searchtype,searchstring):
    try:
        policylist=()
        connection = openmysqlconnection()
        print("connected to the db")
        cursor = connection.cursor(prepared=True)
        inputdata = (searchstring,)
        if searchtype==1:
            sqlquery="SELECT * FROM policy WHERE policy_type = %s"
            cursor.execute(sqlquery, inputdata)
            policylist = cursor.fetchall()
        elif searchtype==2:
            sqlquery="SELECT * FROM policy WHERE duration_in_years = %s"
            cursor.execute(sqlquery,inputdata)
            policylist = cursor.fetchall()
        elif searchtype == 3:
            sqlquery = "SELECT * FROM policy WHERE company_name = %s"
            cursor.execute(sqlquery, inputdata)
            policylist = cursor.fetchall()
        elif searchtype == 4:
            sqlquery = "SELECT * FROM policy WHERE policy_id = %s"
            cursor.execute(sqlquery, inputdata)
            policylist = cursor.fetchall()
        elif searchtype == 5:
            sqlquery = "SELECT * FROM policy WHERE policy_name = %s"
            cursor.execute(sqlquery, inputdata)
            policylist = cursor.fetchall()
        if len(policylist) == 0:
            return "No police for search criteria"

        respone = jsonify(policylist)
        respone.status_code = 200
        return respone

    except Exception as e:
        print(e)
    finally:
        closemysqlconnection(cursor,connection)


if __name__ == '__main__':
    app.run(port=5003, debug=True)