import mysql.connector


def openmysqlconnection():

        connection = mysql.connector.connect(user='root', password='pass@word1',
                                             host='127.0.0.1',
                                             database='policy_management_system')
        return connection

def closemysqlconnection(cursor,connection):
        cursor.close()
        connection.close()