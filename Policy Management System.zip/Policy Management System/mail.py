from flask import Flask
from flask_mail import Mail, Message
app1 = Flask(__name__)

app1.config['MAIL_SERVER'] = 'smtp.gmail.com'
app1.config['MAIL_PORT'] = 465
app1.config['MAIL_USERNAME'] = 'nayakinaveen@gmail.com'
app1.config['MAIL_DEFAULT_SENDER'] = 'nayakinaveen@gmail.com'
app1.config['MAIL_PASSWORD'] = 'ananth123'
app1.config['MAIL_USE_TLS'] = False
app1.config['MAIL_USE_SSL'] = True
mail = Mail(app1)
mail.init_app(app1)
