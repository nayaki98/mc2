from datetime import date
from random import randint,choice
from flask import jsonify
from flask import request
from flask_mail import Message, Mail
from flask_restful import Resource
from mysql.connector import Error
from config import openmysqlconnection, closemysqlconnection
from mail import mail,app1



today = date.today()
mail=Mail(app1)

class UserRegister(Resource):
    def post(self):
        try:
            _json = request.json
            first_name = _json['first_name']
            last_name = _json['last_name']
            date_of_birth = _json['date_of_birth']
            address = _json['address']
            contact_number = _json['contact_number']
            email = _json['email']
            qualification = _json['qualification']
            gender = _json['gender']
            salary = _json['salary']
            pan_number = _json['pan_number']
            emp_type = _json['emp_type']
            emp_name = _json['emp_name']
    #!!!!Emai Validation!!!!!#
            connection=openmysqlconnection()
            cursor = connection.cursor(prepared=True)
            sqlquery="SELECT email FROM user where email=%s"
            inputdata=(email,)
            cursor.execute(sqlquery,inputdata)
            email_temp = cursor.fetchall()
            for itr in email_temp:
                print(itr)
                if (itr[0]==email):
                    return "Email already exists in the database"
        #----USERID GENERATION-------#
            income = int(salary)
            salary_per_year = income * 12
            if int(salary_per_year) <= 500000:
                user_type_id = 'A'
            elif int(salary_per_year) > 500000 & int(salary_per_year) <= 1000000:
                user_type_id = 'B'
            elif int(salary_per_year) > 1000000 & int(salary_per_year) <= 1500000:
                user_type_id = 'C'
            elif int(salary_per_year) > 1500000 & int(salary_per_year) <= 3000000:
                user_type_id = 'D'
            elif int(salary_per_year) > 3000000:
                user_type_id = 'E'

            cursor.execute("SELECT user_id FROM user")
            userlist = cursor.fetchall()
            print(userlist)
            if len(userlist) == 0:
                num = '0001'
            else:
                for itr in userlist:
                    userid = itr[0]
                    print(userid)
                    print(user_type_id,userid.split('-')[0])

                    if user_type_id == (userid.split('-')[0]):
                        latestuid = (userid.split('-')[1])
                    else:
                        latestuid = "0000"
                num = "{:04d}".format(int(latestuid) + 1)
            user_id = user_type_id + '-' + num

        #-----PASSWORD GENERATION------#

            date = today.strftime("%d")
            month = today.strftime("%B")
            random_number = randint(000,999)
            character = choice('#_$')
            password = str(date) + str(month) + str(character) + str(random_number)

        #----Inserting data into database-------#

            sqlQuery = "INSERT INTO user (first_name, last_name, date_of_birth, address, contact_no, email, qualification, gender, salary, pan_no, type_of_employer, name_of_employer,user_id,password) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            bindData = (
            first_name, last_name, date_of_birth, address, contact_number, email, qualification, gender, salary,                pan_number,
            emp_type, emp_name, user_id, password)
            cursor.execute(sqlQuery, bindData)
            connection.commit()
        #-----Sending user_id and password to user-----#
            msg = Message('User Registration Details', sender='nayakinaveen@gmail.com', recipients=[email])
            msg.body = """Thank you for Registration!!! 
                            Dear User your user id is %s and your password is %s""" % (user_id, password)
            mail.send(msg)
            response = jsonify('User Deatils added successfully!')
            return response

        except Error as e:
            print("Error while connecting to MySQL", e)
        finally:
            closemysqlconnection(cursor,connection)

#FETCHING USERLIST FROM DB
class Userlist(Resource):
    def get(self):
        try:
            connection = openmysqlconnection()
            cursor = connection.cursor()
            cursor.execute("SELECT * from user;")
            userList = cursor.fetchall()
            respone = jsonify(userList)
            respone.status_code = 200
            return respone
        except Exception as e:
            print(e)
        finally:
            closemysqlconnection(cursor,connection)




