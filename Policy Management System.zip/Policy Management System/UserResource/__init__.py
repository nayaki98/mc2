
import random
from datetime import date
from random import randint
from flask_restful import Api
import mysql.connector
import pymysql
from flask import Flask
from flask import jsonify
from flask import request
from mysql.connector import Error

app = Flask(__name__)



api = Api(app)

today = date.today()
@app.route('/addUser', methods=['POST'])
def add_user():
        try:
            _json = request.json


            print(_json)
            first_name = _json['first_name']
            last_name = _json['last_name']
            date_of_birth = _json['date_of_birth']
            address = _json['address']
            contact_number = _json['contact_number']
            email = _json['email']
            print(contact_number)
            qualification = _json['qualification']
            gender = _json['gender']
            salary = _json['salary']
            pan_number = _json['pan_number']
            emp_type = _json['emp_type']
            emp_name = _json['emp_name']
            connection = mysql.connector.connect(user='root', password='pass@word1',
                                     host='127.0.0.1',
                                     database='policy_management_system')
            print("connected to the db")
            cursor = connection.cursor()
            income = int(salary)
            salary_per_year = income * 12
            if int(salary_per_year) <= 500000:
                user_type_id = 'A'
            elif int(salary_per_year) > 500000 & int(salary_per_year) <= 1000000:
                user_type_id = 'B'
            elif int(salary_per_year) > 1000000 & int(salary_per_year) <= 1500000:
                user_type_id = 'C'

            elif int(salary_per_year) > 1500000 & int(salary_per_year) <= 3000000:
                    user_type_id = 'D'
            elif int(salary_per_year) > 3000000:
                user_type_id = 'E'
            print(user_type_id)

            num = randint(1_200,9999)


            user_id = user_type_id + '-' + str(num)
            date = today.strftime("%d")

            month = today.strftime("%B")

            random_number = randint(100, 999)
            #random_number = 123
            character = random.choice('$_')            #character = "#"
            password = str(date) + str(month) + str(character) + str(random_number)
            sqlQuery = "INSERT INTO user (first_name, last_name, date_of_birth, address, contact_no, email, qualification, gender, salary, pan_no, type_of_employer, name_of_employer,user_id,password) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            bindData = (
            first_name, last_name, date_of_birth, address, contact_number, email, qualification, gender, salary, pan_number,
            emp_type, emp_name, user_id, password)
            cursor.execute(sqlQuery, bindData)
            connection.commit()
            respone = jsonify('User Deatils added successfully!')
            respone.status_code = 200
            return respone

        except Error as e:
            print("Error while connecting to MySQL", e)


@app.route('/userList')
def userList():
    try:
            connection = mysql.connector.connect(user='root', password='pass@word1',
                                             host='127.0.0.1',
                                             database='policy_management_system')
            print("connected")
            cursor = connection.cursor((pymysql.cursors.DictCursor))
            sqlquerystt = "SELECT * from user;"
            cursor.execute(sqlquerystt)
            rowCount = cursor.fetchall()
            respone = jsonify(rowCount)
            respone.status_code = 200
            return respone
    except Exception as e:
            print(e)
    finally:
            cursor.close()
            connection.close()


if __name__ == '__main__':
    app.run(port=5000, debug=True)

