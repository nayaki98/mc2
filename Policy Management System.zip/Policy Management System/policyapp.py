from PolicyResource.policy import PolicyList,PolicyRegister
from flask_restful import Api
from flask import Flask


app = Flask(__name__)
api = Api(app)
api.add_resource(PolicyRegister,'/policyRegister')
api.add_resource(PolicyList,'/policyList')




if __name__ == '__main__':
    app.run(port=5002, debug=True)