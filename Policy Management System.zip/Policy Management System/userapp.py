from UserResource.user import UserRegister,Userlist
from flask_restful import Api
from flask import Flask


app = Flask(__name__)
api = Api(app)
api.add_resource(UserRegister,'/userRegister')
api.add_resource(Userlist,'/userList')




if __name__ == '__main__':
    app.run(port=5001, debug=True)